boats = "boats"
slips = "slips"
current_boat = "current_boat"